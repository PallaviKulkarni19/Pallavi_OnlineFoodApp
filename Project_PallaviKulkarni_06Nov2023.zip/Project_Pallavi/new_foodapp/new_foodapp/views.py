from django.http import HttpResponse
import mysql.connector as mysql
from django.shortcuts import redirect
from django.shortcuts import render
from django.contrib.auth import authenticate, login
from django.contrib import messages

def menu1(request):
    return render(request,'menu1.html')
 
def menu2(request):
        return render(request,'menu2.html')

def menu3(request):
        return render(request,'menu3.html')

def menu4(request):
        return render(request,'menu4.html')

def Admin(request):
        return render(request,'Admin.html')
            
def Home(request):
    return render(request,'Home.html')

def Signup(request):
    return render(request,'Signup.html')

def Login(request):
    return render(request,'Login.html')

def LoginMain(request):
    return render(request,'LoginMain.html')

def User1Home(request):
    return render(request,'User1Home.html')

def User2Home(request):
    return render(request,'User2Home.html')

def About(request):
    return render(request,'About.html')
def Contact(request):
    return render(request,'Contact.html')

def Insert(req): #for user login 
    #stpe1: get the details of signup page from into this function
    username= req.GET.get("Username")
    email= req.GET.get("Email")
    password= req.GET.get("Password")
   
    #step2: Establish connection between python and mysql db
    
    conn= mysql.connect(user="root",host="localhost",password="root123",database="django")
    print("Connection Established sucessfully b/w Python and DB!!")
    mycr= conn.cursor()
    
    #step3: insert query signup is table name
  #  mycr.execute("create table Signup(username varchar(20),email varchar(30),password varchar(16))")
    que= "insert into users values('{0}','{1}','{2}')".format(username,email,password)
    mycr.execute(que)

    conn.commit()
    
    return redirect("/Login")


def LoginTask(req): 
    Email= req.GET.get("Email")
    Password= req.GET.get("Password")

    conn= mysql.connect(user="root",host="localhost",password="root123",database="django")
    mycr= conn.cursor()
    mycr.execute("SELECT * FROM users WHERE Email = %s AND Password = %s", (Email, Password))
    row = mycr.fetchone() #method to fetch data
    
    if row is None:
        return redirect("/Login")
    else:
        if Email == "userone@gmail.com":   #user 1 email address
            return redirect("/User1Home")
        elif Email == "usertwo@gmail.com":  #user 2 email address
            return redirect("/User2Home")
        elif Email == "Admin1904@gmail.com":  # for admin login
            return redirect("/Admin") # main home page for food app




















'''
def LoginTask(req): #user1
    # login page insertion
    Email= req.GET.get("Email")
    Password= req.GET.get("Password")

    conn= mysql.connect(user="root",host="localhost",password="root123",database="django")
    mycr= conn.cursor()
   # mycr.execute("select *from users")
    mycr.execute("SELECT * FROM users")
    while True:
        row=mycr.fetchall() #method to fetch data
        print("Rows:",row) #checking purpose only
        if row is None:
                break
        elif Email == "userone@gmail.com":  
            print(Email)
            if row[1] == Email and row[2]== Password:
                print(row[1])
                print(row[2])
                return redirect("/User1Home")
            else:
                return redirect("/Login")
            
        elif Email == "usertwo@gmail.com": 
            if row[1] == Email and row[2]== Password:
                    return redirect("/User2Home")
            else:
                    return redirect("/Login")
        



def LoginTask2(req): #user2
    # login page insertion
    Email= req.GET.get("Email")
    Password= req.GET.get("Password")
    conn= mysql.connect(user="root",host="localhost",password="root123",database="django")
    mycr= conn.cursor()
   # mycr.execute("select *from users where username='UserTwo'")
    mycr.execute('SELECT * FROM users WHERE username="UserTwo";')
    while True:
        row=mycr.fetchone() #method to fetch data
        print("Rows:",row) #checking purpose only
        if row is None:
            break
        elif row[1] == Email and row[2]== Password:
            return redirect("/User2Home")
        
    return redirect("/Login")

'''


