from django.urls import path
from . import views


urlpatterns = [
     path('Home', views.Home),
     path('Signup',views.Signup),
     path('Login', views.Login),
     path('LoginTask',views.LoginTask),
   #  path('LoginTask2',views.LoginTask2),
     path('Insert',views.Insert),
     path('LoginMain',views.LoginMain),
     path('menu1',views.menu1),
     path('menu2',views.menu2),
     path('menu3',views.menu3),
     path('menu4',views.menu4),
     path('User1Home',views.User1Home),
     path('User2Home',views.User2Home),
     path('Admin',views.Admin),
     path('About',views.About),
     path('Contact',views.Contact),
]
