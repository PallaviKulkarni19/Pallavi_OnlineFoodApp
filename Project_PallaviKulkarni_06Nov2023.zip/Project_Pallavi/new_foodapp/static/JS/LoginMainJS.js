document.getElementById('restaurant1').addEventListener('click', function() {
    window.location.href = 'menu1';
});

document.getElementById('restaurant2').addEventListener('click', function() {
    window.location.href = 'menu2';
});

document.getElementById('restaurant3').addEventListener('click', function() {
    window.location.href = 'menu3';
});

document.getElementById('restaurant4').addEventListener('click', function() {
    window.location.href = 'menu4';
});