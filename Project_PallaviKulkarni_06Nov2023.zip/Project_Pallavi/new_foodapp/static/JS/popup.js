// popup.js
document.addEventListener("DOMContentLoaded", function() {
    const orderButton = document.getElementById("orderButton");
    const popup = document.getElementById("popup");
    const closePopup = document.getElementById("closePopup");

    orderButton.addEventListener("click", function() {
        popup.style.display = "block";
    });

    closePopup.addEventListener("click", function() {
        popup.style.display = "none";
    });
});