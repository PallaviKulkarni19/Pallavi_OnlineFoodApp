/* VALIDATION FUNCTIONS FOR SIGNUP PAGE - TO VALIDATE USERNAME, PWD, EMAIL*/

function Name_Validate() //-----------------for name function
{
    /*   alert("Welcome to NAME Register Validate Function!!!"); */
    var name = document.getElementById("nm").value;
    var err1 = document.getElementById("err1");
    var reg = /^[a-zA-Z]*$/;
    if (!reg.test(name)) {
        err1.innerHTML = "*PLEASE ENTER ALPHABETS ONLY!!";
        err1.style.color = "red";
    } else {
        err1.innerHTML = "";
    }
}


function Email_Validate()

{
    var email = document.getElementById("em").value;
    var err3 = document.getElementById("err3");

    //  var reg = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/; //abc@gmail.com

    var reg = /^[A-Za-z0-9](([_\.\-]?[a-zA-Z0-9]+)*)@([A-Za-z0-9]+)(([\.\-]?[a-zA-Z0-9]+)*)\.([A-Za-z]{2,3})$/; // abc@gmail.com or abc@gmail.co.in
    //        pallavi   _        kulkarni       @gmail            .     com             .in (or co.in)

    if (!reg.test(email)) {
        err3.innerHTML = "*PLEASE ENTER VALID EMAIL ID!!";
        err3.style.color = "red";
    } else {
        err3.innerHTML = "";
    }

}


function Pass_Validate() //-----------------for password function
{
    var pwd = document.getElementById("ps").value;
    var err2 = document.getElementById("err2");

    var reg = /^([a-zA-Z0-9@*#]{8,15})$/;

    if (!reg.test(pwd)) {
        err2.innerHTML = "*PLEASE ENTER VALID PASSWORD : [a-zA-Z0-9@*#]!!";
        err2.style.color = "red";
    } else {
        err2.innerHTML = "";
    }
}