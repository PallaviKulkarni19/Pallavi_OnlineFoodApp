function LoginValidation() {
    const email = document.getElementById("em").value;
    const password = document.getElementById("pass").value;
    const errorMessage = document.getElementById("error-message");

    if (username === "" || password === "") {
        errorMessage.style.display = "block";
    } else {
        // Perform server-side validation here
        // For demonstration purposes, we'll just show a successful login message
        alert("Login successful");
    }
}