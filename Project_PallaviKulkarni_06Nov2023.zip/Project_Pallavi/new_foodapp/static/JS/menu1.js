var cart = {};

function addToCart(name, price) {
    if (!cart[name]) {
        cart[name] = {
            price: price,
            quantity: 1
        };
    } else {
        cart[name].quantity++;
    }
    displayCart();
}

function removeFromCart(name) {
    if (cart[name].quantity > 1) {
        cart[name].quantity--;
    } else {
        delete cart[name];
    }
    displayCart();
}

function displayCart() {
    var cartDiv = document.getElementById('cart');
    cartDiv.innerHTML = '';
    var total = 0;
    for (var item in cart) {
        total += cart[item].price * cart[item].quantity;
        cartDiv.innerHTML += '<p>' + item + ' - ₹' + cart[item].price + ' x ' + cart[item].quantity + '<button onclick="removeFromCart(\'' + item + '\')">Remove</button></p>';
    }
    cartDiv.innerHTML += '<p>Total: ₹' + total + '</p>';
}